<?php


class NavigationView
{
	private static $regURL = "register";


	public function wantsToReg() {
		return isset($_GET[self::$regURL]) == false;
	}

	public function getReturnURL()
	{
		return ($this->wantsToReg() ? "<a href='?register'>Register<a>": "<a href='?'>Back To Login<a>");
	}
}