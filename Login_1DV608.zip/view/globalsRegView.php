<?php

class globalsRegView
{
	protected static $userPostID 	 = "RegView::Username";
	protected static $passPostID 	 = "RegView::Password";
	protected static $pass2PostID 	 = "RegView::Password2";
	protected static $submitPostID 	 = "RegView::submit";

	public function wantsToCreateUser() {
		
		return isset($_POST[self::$submitPostID]);
	}


	public function getUserName()
	{
		if(isset($_POST[self::$userPostID]))
		{
			return $_POST[self::$userPostID];
		}
		return "";
	}
	
	public function getPass()
	{
		if(isset($_POST[self::$passPostID]))
		{
			return $_POST[self::$userPostID];
		}
		return "";
	}

	public function getPass2()
	{
		if(isset($_POST[self::$pass2PostID]))
		{
			return $_POST[self::$pass2PostID];
		}
		return "";
	}

	public function getUserNameSession()
	{	
		$this->setUserNameSession();
		
		return $_SESSION['unReg'];	
	}

	public function setUserNameSession()
	{
		if($this->wantsToCreateUser())
		{
			$_SESSION["unReg"] = $this->getUserName();	
		}
		else
		{
			$_SESSION["unReg"]="";
		}
		
	}

}