<?php

class RegFacade {
	private $users;

	public function __construct( userDAL $dal) {
		$this->dal = $dal;
	
	}

	public function add(user $user) {
		
		$this->dal->add($user);	
	}

	public function getProducts() {
		return $this->dal->getUsers();
	}
}