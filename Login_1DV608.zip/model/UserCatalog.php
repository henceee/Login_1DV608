<?php
require_once("model\User.php");
class UserCatalog
{	

	private $users = array();

	public function add(User $toBeAdded)
	{
		if(!$this->userExists($toBeAdded))
		{
			$key = $toBeAdded->getID();	
			$this->users[$key] = $toBeAdded;
		}	
		
	}

	/**
	 * @return array of model\User
	 */
	public function getUsers() {
		return $this->users;
	}

	public function userExists($checkUser)
	{
		foreach ($this->users as $user)
		{
			if ($user->getUsername() === $checkUser->getUsername()) {
				return true;
			}
		}

		return false;
	}
	
}