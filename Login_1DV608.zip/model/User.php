<?php

class noUserNameException extends \Exception {};
class noPassWordException extends \Exception {};


class User
{

	private $username;

	private $password;

	private $id;

	function __construct($username,$password,$id=null)
	{			
		if(is_string($username) == false || strlen($username) < 3)
		{
			throw new noUserNameException();
		}
		if(is_string($password) == false || strlen($password) < 6)
		{
			throw new noPassWordException();
		}

		$this->username = $username;
		$this->password = $password;

		if(!isset($id))
		{
			$this->id = uniqid();

		}else{

			if(!empty($id))
			{
				$this->id = $id;
			}
		}
		
				
	}	

	public function getUsername()
	{
		return $this->username;
	}
	
	
	public function getPassword()
	{
		return $this->password;
	}
	
	public function getID()
	{
		return $this->id;
	}

}