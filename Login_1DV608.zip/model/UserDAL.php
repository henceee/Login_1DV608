<?php
require_once("model/UserCatalog.php");
class UserDAL
{
	private static $table = "users";
	

	function __construct(\mysqli $db)
	{
		$this->database = $db;	
		$this->userCatalog = new UserCatalog();		
	}

	public function getUsers()
	{	

		$stmt = $this->database->prepare("SELECT * FROM " . self::$table);
		if ($stmt === FALSE) {
			throw new Exception($this->database->error);
		}

		$stmt->execute();
	 	
	    $stmt->bind_result($id, $userName, $password);

	    while ($stmt->fetch())
	    {	
	    	$user = new User($userName, $password,$id);
	    	$this->userCatalog->add($user);
		}

		return  $this->userCatalog;	

	}

	public function add(User $toBeAdded)
	{	

		$this->userCatalog = $this->getUsers();
		
		if(!$this->userCatalog->userExists($toBeAdded))
		{	
			$stmt = $this->database->prepare("INSERT INTO  `".self::$table."`(
				`ID` , `Username` , `Password`)
					VALUES (?, ?, ?)");
			if ($stmt === FALSE) {
				throw new Exception($this->database->error);
			}
			$id = $toBeAdded->getID();
			$username = $toBeAdded->getUsername();
			$password = md5($toBeAdded->getPassword());
			$stmt->bind_param('sss', $id, $username, $password);

			$stmt->execute();
			$this->userCatalog->add($toBeAdded);
		}
		else
		{
			throw new  Exception("User with this userName already exists.");
			
		}
	}
}


