<?php
require_once("model/UserCatalog.php");
require_once("model/RegFacade.php");
require_once("model/UserDAL.php");
require_once("view/NavigationView.php");
require_once("view/RegView.php");
require_once('view/LoginView.php');
require_once("controller/LoginController.php");
require_once("controller/RegisterController.php");

class MasterController
{
	private $userController;
	private $navigationView;
	private $userDAL;

	function __construct()
	{
		$this->mysqli = new mysqli("localhost", "root", "", "user");
		if (mysqli_connect_errno())
		{
		    printf("Connect failed: %s\n", mysqli_connect_error());
		    exit();		    
		}

		$this->userDAL = new UserDAL($this->mysqli);
		$this->navigationView = new NavigationView();
	}

	public function handleInput() {
		if ($this->navigationView->wantsToReg())
		{
			$login = new LoginController($this->userDAL->getUsers(),$this->navigationView);
			$login->doLogin();
			$this->view = $login->getOutPut();

			$this->view->response = (isset($_SESSION['user'])) ?
			$this->view->generateLogoutButtonHTML() : $this->view->generateLoginFormHTML();

		} 
		else 
		{
			$model = new RegFacade($this->userDAL);
			$this->view = new RegView($this->navigationView);	
			$regControl = new RegisterController($model,$this->view);
			$regControl->addUser();
			$this->view->response=$this->view->getHTML();

		}

		$this->mysqli->close();
	}

	public function generateOutPut()
	{
		return $this->view;
	}
}